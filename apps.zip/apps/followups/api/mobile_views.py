from rest_framework import generics

from apps.followups.models import FollowUp
from apps.followups.api.serializers import FollowUpSerializer
from apps.accounts.models import User
from apps.accounts.permissions import CanAccessLeads


class MobileFollowUpListView(generics.ListAPIView):
    serializer_class = FollowUpSerializer
    permission_classes = (CanAccessLeads,)

    def get_queryset(self):
        user = self.request.user

        queryset = (
            FollowUp.objects
            .select_related("lead", "caller")
            .filter(status=FollowUp.Status.PENDING)
            .order_by("scheduled_at")
        )

        if user.role == User.Role.CALLER:
            return queryset.filter(caller=user)

        if user.role in {
            User.Role.SUPER_ADMIN,
            User.Role.ADMIN,
            User.Role.MANAGER,
        }:
            return queryset

        return FollowUp.objects.none()